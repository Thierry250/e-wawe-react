// Vite serves the React app and proxies API requests to the local Node server.
import { defineConfig, loadEnv } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), "");
  const apiPort = Number(env.API_PORT || 3002);

  return {
    plugins: [react()],
    server: {
      host: "127.0.0.1",
      fs: { deny: ["**/data/**", "**/server/**"] },
      proxy: { "/api": `http://127.0.0.1:${apiPort}` },
    },
  };
});

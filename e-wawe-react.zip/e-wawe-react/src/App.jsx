import { useCallback, useEffect, useRef, useState } from "react";

// Shared API, upload, location, and display settings used by the interface.
const API = "/api";
const TOKEN_KEY = "ewawe-auth-token";
const PHOTO_LIMIT = 5;
const MAX_PHOTO_BYTES = 2 * 1024 * 1024;
const neighborhoods = [
  "Kiyovu",
  "Kimihurura",
  "Nyarutarama",
  "Kacyiru",
  "Remera",
  "Kibagabaga",
  "Gacuriro",
  "Other",
];
const propertyTypes = ["Apartment", "House", "Townhouse", "Villa", "Other"];
const passwordPattern =
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,128}$/;
const usd = new Intl.NumberFormat("en-US", {
  style: "currency",
  currency: "USD",
  maximumFractionDigits: 0,
});

// Adds the current session token to API calls and returns useful server errors.
async function request(path, options = {}) {
  const headers = {
    "Content-Type": "application/json",
    ...(options.headers || {}),
  };
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) headers.Authorization = `Bearer ${token}`;
  const response = await fetch(`${API}${path}`, { ...options, headers });
  const data = await response.json().catch(() => ({}));
  if (!response.ok)
    throw new Error(data.error || "Something went wrong. Please try again.");
  return data;
}

// App owns routing, shared search state, session recovery, and global notices.
function App() {
  const [view, setView] = useState("home");
  const [user, setUser] = useState(null);
  const [properties, setProperties] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [search, setSearch] = useState({
    q: "",
    neighborhood: "",
    bedrooms: "",
    maxRent: "",
  });
  const [toast, setToast] = useState("");
  const selectedProperty = properties.find(
    (property) => property.id === selectedId,
  );

  const loadProperties = useCallback(async () => {
    try {
      const query = new URLSearchParams();
      if (search.q) query.set("q", search.q);
      if (search.neighborhood) query.set("neighborhood", search.neighborhood);
      if (search.bedrooms) query.set("bedrooms", search.bedrooms);
      if (search.maxRent) query.set("maxRent", search.maxRent);
      const { properties: items } = await request(
        `/properties?${query.toString()}`,
      );
      setProperties(items);
    } catch (error) {
      flash(error.message);
    }
  }, [search.q, search.neighborhood, search.bedrooms, search.maxRent]);

  useEffect(() => {
    loadProperties();
  }, [loadProperties]);
  useEffect(() => {
    const token = localStorage.getItem(TOKEN_KEY);
    if (!token) return;
    request("/auth/me")
      .then(({ user: account }) => setUser(account))
      .catch(() => {
        localStorage.removeItem(TOKEN_KEY);
        setUser(null);
      });
  }, []);
  useEffect(() => {
    if (!user || !["owner", "agent"].includes(user.role)) return;
    const params = new URLSearchParams(window.location.search);
    if (!params.has("billing_return")) return;
    const transactionId = params.get("transaction_id");
    const txRef = params.get("tx_ref");
    window.history.replaceState({}, "", window.location.pathname);
    if (!transactionId || !txRef || params.get("status") !== "successful") {
      flash(
        "Checkout was not completed. Your account remains on its current plan.",
      );
      return;
    }
    request(
      `/billing/verify?${new URLSearchParams({ transaction_id: transactionId, tx_ref: txRef })}`,
    )
      .then(({ plan }) => {
        setView("dashboard");
        flash(`${plan.name} is now active on your account.`);
      })
      .catch((error) => flash(error.message));
  }, [user]);
  useEffect(() => {
    if (!toast) return undefined;
    const timer = window.setTimeout(() => setToast(""), 3800);
    return () => window.clearTimeout(timer);
  }, [toast]);

  function flash(message) {
    setToast(message);
  }
  const navigate = useCallback(
    (nextView) => {
      if (
        nextView === "dashboard" &&
        !["owner", "agent"].includes(user?.role)
      ) {
        setView("owner-login");
      } else setView(nextView);
      window.scrollTo({ top: 0, behavior: "smooth" });
    },
    [user],
  );
  function openProperty(id) {
    setSelectedId(id);
    setView("property");
    request(`/properties/${id}`)
      .then(({ property }) => {
        setProperties((current) =>
          current.map((item) => (item.id === id ? property : item)),
        );
      })
      .catch((error) => flash(error.message));
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  async function signOut() {
    try {
      await request("/auth/logout", { method: "POST" });
    } catch {
      /* The session may already have expired. */
    }
    localStorage.removeItem(TOKEN_KEY);
    setUser(null);
    navigate("home");
  }
  async function authenticate(form, mode, role) {
    const values = Object.fromEntries(new FormData(form).entries());
    const endpoint = mode === "signup" ? "/auth/signup" : "/auth/login";
    if (mode === "signup") {
      values.role = role === "owner" ? values.role || "owner" : "renter";
      values.termsAccepted = form.elements.termsAccepted.checked;
    }
    try {
      const result = await request(endpoint, {
        method: "POST",
        body: JSON.stringify(values),
      });
      localStorage.setItem(TOKEN_KEY, result.token);
      setUser(result.user);
      if (result.user.role === "owner" || result.user.role === "agent") {
        setView("dashboard");
        window.scrollTo({ top: 0, behavior: "smooth" });
      } else navigate("listings");
      flash(
        mode === "signup"
          ? "Your E-wawe account is ready."
          : `Welcome back, ${result.user.firstName}.`,
      );
    } catch (error) {
      return error.message;
    }
    return "";
  }

  // Exchange a Google credential for an E-wawe session after server verification.
  async function authenticateGoogle(credential, mode, role, details = {}) {
    const isSignup = mode === "signup";
    const isProvider = ["owner", "agent"].includes(role);
    try {
      const result = await request(
        isSignup ? "/auth/google/signup" : "/auth/google/login",
        {
          method: "POST",
          body: JSON.stringify(
            isSignup
              ? { ...details, credential, role }
              : { credential, accountType: isProvider ? "provider" : "renter" },
          ),
        },
      );
      localStorage.setItem(TOKEN_KEY, result.token);
      setUser(result.user);
      if (isProvider) {
        setView("dashboard");
        window.scrollTo({ top: 0, behavior: "smooth" });
      } else navigate("listings");
      flash(
        isSignup
          ? `Your E-wawe account is ready, ${result.user.firstName}.`
          : `Welcome back, ${result.user.firstName}.`,
      );
      return "";
    } catch (error) {
      return error.message;
    }
  }

  return (
    <>
      <Header user={user} navigate={navigate} signOut={signOut} />
      {view === "home" && (
        <Home
          properties={properties}
          search={search}
          setSearch={setSearch}
          navigate={navigate}
          openProperty={openProperty}
        />
      )}
      {view === "listings" && (
        <Listings
          properties={properties}
          search={search}
          setSearch={setSearch}
          openProperty={openProperty}
          navigate={navigate}
        />
      )}
      {view === "property" && (
        <PropertyDetail
          property={selectedProperty}
          openContact={async (id) => {
            try {
              return (
                await request(`/properties/${id}/contact`, {
                  method: "POST",
                  body: "{}",
                })
              ).contact;
            } catch (error) {
              flash(error.message);
              return null;
            }
          }}
        />
      )}
      {view === "signin" && (
        <AuthPage
          mode="login"
          role="renter"
          onSubmit={authenticate}
          onGoogle={authenticateGoogle}
          navigate={navigate}
        />
      )}
      {view === "owner-login" && (
        <AuthPage
          mode="login"
          role="owner"
          onSubmit={authenticate}
          onGoogle={authenticateGoogle}
          navigate={navigate}
        />
      )}
      {view === "signup-renter" && (
        <AuthPage
          mode="signup"
          role="renter"
          onSubmit={authenticate}
          onGoogle={authenticateGoogle}
          navigate={navigate}
        />
      )}
      {view === "signup-provider" && (
        <AuthPage
          mode="signup"
          role="owner"
          onSubmit={authenticate}
          onGoogle={authenticateGoogle}
          navigate={navigate}
        />
      )}
      {view === "dashboard" && (
        <Dashboard user={user} navigate={navigate} flash={flash} />
      )}
      {view === "terms" && <Terms navigate={navigate} />}
      {toast && (
        <div className="toast" role="status">
          {toast}
          <button onClick={() => setToast("")} aria-label="Dismiss">
            ×
          </button>
        </div>
      )}
      <Footer navigate={navigate} />
    </>
  );
}

// Header provides renter navigation and role-aware account actions.
function Header({ user, navigate, signOut }) {
  return (
    <header className="topbar">
      <button className="brand" onClick={() => navigate("home")}>
        E-wawe<span>.</span>
      </button>
      <nav className="nav">
        <button onClick={() => navigate("listings")}>Find a home</button>
        <button
          onClick={() =>
            navigate(
              user && ["owner", "agent"].includes(user.role)
                ? "dashboard"
                : "owner-login",
            )
          }
        >
          List your property
        </button>
        {user ? (
          <>
            <span className="nav-user">{user.firstName}</span>
            <button className="nav-cta" onClick={signOut}>
              Sign out
            </button>
          </>
        ) : (
          <>
            <button onClick={() => navigate("signin")}>Sign in</button>
            <button
              className="nav-cta"
              onClick={() => navigate("signup-renter")}
            >
              Join E-wawe
            </button>
          </>
        )}
      </nav>
    </header>
  );
}

// Home presents the hero, property search, featured homes, and provider callout.
function Home({ properties, search, setSearch, navigate, openProperty }) {
  return (
    <>
      <main>
        <section className="hero">
          <div className="hero-copy">
            <div className="eyebrow">A better way to find where you belong</div>
            <h1>Come home to something exceptional.</h1>
            <p>
              Discover long-term rentals chosen for the way you want to live.
              Thoughtful homes, trusted people, and a more personal search.
            </p>
            <button
              className="btn btn-light"
              onClick={() => navigate("listings")}
            >
              Explore homes&nbsp; →
            </button>
          </div>
        </section>
        <SearchBox
          search={search}
          setSearch={setSearch}
          onSubmit={() => navigate("listings")}
        />
        <section className="section">
          <div className="section-head">
            <div>
              <div className="eyebrow">Handpicked for your next chapter</div>
              <h2>Homes worth staying for.</h2>
              <p>
                Explore standout long-term rentals from trusted local owners and
                agents.
              </p>
            </div>
            <button className="text-link" onClick={() => navigate("listings")}>
              View all homes →
            </button>
          </div>
          <PropertyGrid
            properties={properties.slice(0, 3)}
            openProperty={openProperty}
          />
        </section>
        <section className="owner-promo">
          <div>
            <div className="eyebrow">For owners &amp; local experts</div>
            <h2>Your properties, in good company.</h2>
            <p>
              Showcase your homes, connect with serious renters, and understand
              how your listings perform.
            </p>
          </div>
          <button className="btn" onClick={() => navigate("owner-login")}>
            List your property
          </button>
        </section>
      </main>
    </>
  );
}

// SearchBox shares the location, bedroom, and rent filters across pages.
function SearchBox({ search, setSearch, onSubmit }) {
  return (
    <form
      className="searchbox"
      onSubmit={(event) => {
        event.preventDefault();
        onSubmit();
      }}
    >
      <input
        aria-label="Search Kigali neighborhoods"
        placeholder="Neighborhood or property"
        value={search.q}
        onChange={(event) => setSearch({ ...search, q: event.target.value })}
      />
      <select
        aria-label="Neighborhood"
        value={search.neighborhood}
        onChange={(event) =>
          setSearch({ ...search, neighborhood: event.target.value })
        }
      >
        <option value="">All neighborhoods</option>
        {neighborhoods
          .filter((item) => item !== "Other")
          .map((item) => (
            <option key={item}>{item}</option>
          ))}
      </select>
      <select
        aria-label="Bedrooms"
        value={search.bedrooms}
        onChange={(event) =>
          setSearch({ ...search, bedrooms: event.target.value })
        }
      >
        <option value="">Any bedrooms</option>
        {[1, 2, 3, 4].map((num) => (
          <option key={num} value={num}>
            {num}+ bedrooms
          </option>
        ))}
      </select>
      <select
        aria-label="Maximum monthly rent"
        value={search.maxRent}
        onChange={(event) =>
          setSearch({ ...search, maxRent: event.target.value })
        }
      >
        <option value="">Any budget</option>
        <option value="2000">Up to $2,000</option>
        <option value="3000">Up to $3,000</option>
        <option value="4000">Up to $4,000</option>
        <option value="6000">Up to $6,000</option>
      </select>
      <button className="btn">Search homes</button>
    </form>
  );
}

// Listings shows filtered homes in a full-width layout.
function Listings({ properties, search, setSearch, openProperty, navigate }) {
  return (
    <main className="page-wrap">
      <div className="crumb">Home / Find a home</div>
      <div className="eyebrow">Long-term rentals in Kigali</div>
      <h1 className="page-title">Find a place to call yours.</h1>
      <p className="muted">
        {properties.length} homes available for long-term rent
      </p>
      <SearchBox search={search} setSearch={setSearch} onSubmit={() => {}} />
      <div className="listing-layout">
        <PropertyGrid properties={properties} openProperty={openProperty} />
      </div>
      {properties.length === 0 && (
        <div className="empty-state">
          No homes match those filters. Try widening your search.
        </div>
      )}
      <button className="text-link back-link" onClick={() => navigate("home")}>
        ← Back to home
      </button>
    </main>
  );
}

// PropertyGrid renders reusable cards with rent, location, and floor area.
function PropertyGrid({ properties, openProperty }) {
  if (!properties.length)
    return <div className="empty-state">No properties to show yet.</div>;
  return (
    <div className="cards">
      {properties.map((property, index) => (
        <article className="card" key={property.id}>
          <button
            className="card-open"
            onClick={() => openProperty(property.id)}
            aria-label={`View ${property.title}`}
          >
            <div
              className="card-img"
              style={{
                backgroundImage: `url("${property.images?.[0] || ""}")`,
              }}
            >
              <span className="badge">
                {property.promoted ? "Featured" : "Available now"}
              </span>
            </div>
          </button>
          <div className="card-body">
            <div className="price">
              {usd.format(property.rent)} <small>/ month</small>
            </div>
            <button
              className="card-title"
              onClick={() => openProperty(property.id)}
            >
              {property.title}
            </button>
            <p className="address">
              {property.neighborhood}, {property.city}
            </p>
            <div className="facts">
              <span>
                <b>{property.bedrooms}</b> bd
              </span>
              <span>
                <b>{property.bathrooms}</b> ba
              </span>
              <span>
                <b>{property.areaSqm}</b> m²
              </span>
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}

// PropertyDetail displays the listing and reveals contact details on request.
function PropertyDetail({ property, openContact }) {
  const [contact, setContact] = useState(null);
  const [loading, setLoading] = useState(false);
  useEffect(() => {
    setContact(null);
  }, [property?.id]);
  if (!property)
    return (
      <main className="page-wrap">
        <div className="empty-state">
          Choose a property from the home search.
        </div>
      </main>
    );
  async function revealContact() {
    if (contact || loading) return;
    setLoading(true);
    const result = await openContact(property.id);
    setContact(result);
    setLoading(false);
  }
  return (
    <main className="page-wrap">
      <div className="crumb">Homes / Kigali / {property.neighborhood}</div>
      <div className="detail-grid">
        <img src={property.images?.[0]} alt={`${property.title} interior`} />
        <div className="detail-side">
          {property.images?.slice(1, 3).map((image, index) => (
            <img
              key={image}
              src={image}
              alt={`${property.title} interior ${index + 2}`}
            />
          ))}
        </div>
      </div>
      <div className="detail-meta">
        <section>
          <div className="eyebrow">
            {property.propertyType} · Available{" "}
            {property.availableDate || "now"}
          </div>
          <h1 className="page-title">{property.title}</h1>
          <p className="address">
            {property.neighborhood}, {property.city}, Rwanda
          </p>
          <div className="facts detail-facts">
            <span>
              <b>{property.bedrooms}</b> bedrooms
            </span>
            <span>
              <b>{property.bathrooms}</b> bathrooms
            </span>
            <span>
              <b>{property.areaSqm}</b> m²
            </span>
          </div>
          <h3>A little more room to live well.</h3>
          <p className="description">{property.description}</p>
          <h3>Home details</h3>
          <div className="amenities">
            {(property.amenities || []).map((item) => (
              <span key={item}>✓ {item}</span>
            ))}
          </div>
          <h3>Lease terms</h3>
          <p className="description">
            {usd.format(property.rent)} monthly rent ·{" "}
            {property.leaseTerm || "12 months"} · Available{" "}
            {property.availableDate || "now"}
          </p>
        </section>
        <aside className="panel contact-panel">
          <div className="price">
            {usd.format(property.rent)} <small>/ month</small>
          </div>
          <p>Long-term lease · Kigali, Rwanda</p>
          <div className="facts">
            <span>
              <b>{property.bedrooms}</b> bd
            </span>
            <span>
              <b>{property.bathrooms}</b> ba
            </span>
            <span>
              <b>{property.areaSqm}</b> m²
            </span>
          </div>
          <p className="listed-by">
            Listed by{" "}
            <strong>
              {property.contactRole === "agent"
                ? "Property agent"
                : "Property owner"}
            </strong>
          </p>
          <p className="muted small">
            Choose a button to reveal available contact details.
          </p>
          <button
            className="btn full"
            onClick={revealContact}
            disabled={loading}
          >
            {loading
              ? "Loading…"
              : property.contactRole === "agent"
                ? "Contact agent"
                : "Contact owner"}
          </button>
          {contact && (
            <div className="contact-details">
              <a href={`tel:${contact.phone.replace(/\s/g, "")}`}>
                ☎ &nbsp; {contact.phone}
              </a>
              <a href={`mailto:${contact.email}`}>
                ✉ &nbsp; Email {contact.name}
              </a>
              <a
                href={`https://wa.me/${contact.whatsapp.replace(/\D/g, "")}`}
                target="_blank"
                rel="noreferrer"
              >
                ◉ &nbsp; WhatsApp
              </a>
            </div>
          )}
        </aside>
      </div>
    </main>
  );
}

// AuthPage handles renter/provider sign-in and validated account registration.
function AuthPage({ mode, role, onSubmit, onGoogle, navigate }) {
  const isSignup = mode === "signup";
  const isProvider = role === "owner";
  const [error, setError] = useState("");
  const [googleCredential, setGoogleCredential] = useState("");
  const [googleProfile, setGoogleProfile] = useState(null);
  const [googleNames, setGoogleNames] = useState({
    firstName: "",
    lastName: "",
  });
  const [googleBusy, setGoogleBusy] = useState(false);
  const googleButtonRef = useRef(null);
  const googleHandlerRef = useRef(onGoogle);
  const googleClientId = import.meta.env.VITE_GOOGLE_CLIENT_ID || "";

  useEffect(() => {
    googleHandlerRef.current = onGoogle;
  }, [onGoogle]);

  useEffect(() => {
    if (!googleClientId || !googleButtonRef.current) return undefined;
    let isCurrent = true;
    const renderButton = () => {
      if (
        !isCurrent ||
        !window.google?.accounts?.id ||
        !googleButtonRef.current
      )
        return;
      googleButtonRef.current.replaceChildren();
      window.google.accounts.id.initialize({
        client_id: googleClientId,
        callback: async ({ credential }) => {
          setError("");
          setGoogleBusy(true);
          try {
            if (isSignup) {
              const result = await request("/auth/google/profile", {
                method: "POST",
                body: JSON.stringify({ credential }),
              });
              if (!isCurrent) return;
              setGoogleCredential(credential);
              setGoogleProfile(result.identity);
              setGoogleNames({
                firstName: result.identity.firstName || "",
                lastName: result.identity.lastName || "",
              });
            } else {
              const message = await googleHandlerRef.current(
                credential,
                "login",
                isProvider ? "owner" : "renter",
              );
              if (isCurrent) setError(message || "");
            }
          } catch (googleError) {
            if (isCurrent) setError(googleError.message);
          } finally {
            if (isCurrent) setGoogleBusy(false);
          }
        },
      });
      window.google.accounts.id.renderButton(googleButtonRef.current, {
        type: "standard",
        theme: "outline",
        size: "large",
        text: isSignup ? "signup_with" : "signin_with",
        shape: "rectangular",
        logo_alignment: "left",
        width: Math.min(320, googleButtonRef.current.clientWidth || 320),
      });
    };
    const scriptUrl = "https://accounts.google.com/gsi/client";
    let script = document.querySelector(`script[src="${scriptUrl}"]`);
    const onLoad = () => renderButton();
    const onError = () => {
      if (isCurrent)
        setError("Google sign-in could not load. Please try again.");
    };
    if (window.google?.accounts?.id) renderButton();
    else {
      if (!script) {
        script = document.createElement("script");
        script.src = scriptUrl;
        script.async = true;
        script.defer = true;
        document.head.appendChild(script);
      }
      script.addEventListener("load", onLoad);
      script.addEventListener("error", onError);
    }
    return () => {
      isCurrent = false;
      script?.removeEventListener("load", onLoad);
      script?.removeEventListener("error", onError);
    };
  }, [googleClientId, googleProfile, isProvider, isSignup]);

  async function submit(event) {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    if (googleCredential && googleProfile) {
      const values = Object.fromEntries(new FormData(form).entries());
      const accountRole = isProvider ? values.role : "renter";
      const message = await onGoogle(googleCredential, "signup", accountRole, {
        ...values,
        firstName: googleNames.firstName,
        lastName: googleNames.lastName,
        email: googleProfile.email,
        termsAccepted: form.elements.termsAccepted.checked,
      });
      setError(message || "");
      return;
    }
    const password = form.elements.password;
    const confirmation = form.elements.confirmPassword;
    if (confirmation) {
      confirmation.setCustomValidity(
        confirmation.value === password.value ? "" : "Passwords must match.",
      );
      if (!form.reportValidity()) return;
    }
    const message = await onSubmit(form, mode, isProvider ? "owner" : "renter");
    setError(message || "");
  }
  return (
    <main className="auth-wrap">
      <div className="auth-image">
        <blockquote>
          {isSignup
            ? isProvider
              ? "Share your property with the people ready to call it home."
              : "Make room for the life you want to live."
            : isProvider
              ? "Your next chapter starts with the right home."
              : "A home should feel like the beginning of something."}
        </blockquote>
      </div>
      <section className="auth-form">
        <div className="form-inner">
          <div className="eyebrow">
            {isSignup
              ? isProvider
                ? "Owner & agent account"
                : "Renter account"
              : isProvider
                ? "Owner & agent portal"
                : "Welcome back"}
          </div>
          <h1>
            {isSignup
              ? isProvider
                ? "List your property."
                : "Make yourself at home."
              : isProvider
                ? "Sign in to manage your properties."
                : "Sign in to E-wawe."}
          </h1>
          <p>
            {isSignup
              ? isProvider
                ? "Create an account to publish homes and view your listing analytics."
                : "Create an account to save homes and connect with property owners and agents."
              : isProvider
                ? "Access your listings, renter inquiries, and property analytics."
                : "Pick up where you left off and find your next place to call home."}
          </p>
          {isSignup && (
            <div className="switch">
              <button
                className={!isProvider ? "active" : ""}
                onClick={() => navigate("signup-renter")}
              >
                I’m looking to rent
              </button>
              <button
                className={isProvider ? "active" : ""}
                onClick={() => navigate("signup-provider")}
              >
                I list properties
              </button>
            </div>
          )}
          {!isSignup && isProvider && (
            <div className="switch">
              <button onClick={() => navigate("signin")}>Renter</button>
              <button className="active">Owner / Agent</button>
            </div>
          )}
          {!isSignup && !isProvider && (
            <div className="switch">
              <button className="active">Renter</button>
              <button onClick={() => navigate("owner-login")}>
                Owner / Agent
              </button>
            </div>
          )}
          <div className="google-auth-block">
            {!googleProfile && (
              <div className="google-button" ref={googleButtonRef}></div>
            )}
            {!googleClientId && (
              <p className="google-config-note">
                Google sign-in needs a Google web client ID in your .env file.
              </p>
            )}
            {googleBusy && (
              <p className="muted" role="status">
                {isSignup ? "Verifying your Google account…" : "Signing in…"}
              </p>
            )}
            {googleProfile && (
              <>
                <div className="google-verified" role="status">
                  <span>Verified Google account</span>
                  <strong>{googleProfile.email}</strong>
                </div>
                <button
                  className="text-link google-change"
                  type="button"
                  onClick={() => {
                    setGoogleCredential("");
                    setGoogleProfile(null);
                    setGoogleNames({ firstName: "", lastName: "" });
                    setError("");
                  }}
                >
                  Use email and password instead
                </button>
              </>
            )}
          </div>
          <div className="auth-divider">
            <span>
              {googleProfile
                ? "Complete your profile"
                : "or continue with email"}
            </span>
          </div>
          <form onSubmit={submit} noValidate={false}>
            {isSignup && isProvider && (
              <div className="form-row">
                <label htmlFor="provider-role">Account type</label>
                <select
                  id="provider-role"
                  name="role"
                  defaultValue="owner"
                  required
                >
                  <option value="owner">Property owner</option>
                  <option value="agent">Property agent</option>
                </select>
              </div>
            )}
            {isSignup && !googleProfile && (
              <div className="form-grid">
                <Field
                  id="firstName"
                  label="First name"
                  autoComplete="given-name"
                  minLength={2}
                  maxLength={50}
                  pattern="[\p{L}][\p{L}\p{M} ’'-]{1,49}"
                  title="Use 2–50 letters, spaces, apostrophes, or hyphens."
                  required
                />
                <Field
                  id="lastName"
                  label="Last name"
                  autoComplete="family-name"
                  minLength={2}
                  maxLength={50}
                  pattern="[\p{L}][\p{L}\p{M} ’'-]{1,49}"
                  title="Use 2–50 letters, spaces, apostrophes, or hyphens."
                  required
                />
                <Field
                  id="phone"
                  label="Rwanda phone number"
                  type="tel"
                  autoComplete="tel"
                  inputMode="tel"
                  minLength={10}
                  maxLength={16}
                  pattern="(?:\+250 ?|0)7[0-9]{2} ?[0-9]{3} ?[0-9]{3}"
                  title="Use +250 7XX XXX XXX or 07XX XXX XXX."
                  placeholder="+250 788 123 456"
                  required
                />
                <Field
                  id="age"
                  label="Age"
                  type="number"
                  min={18}
                  max={120}
                  step={1}
                  inputMode="numeric"
                  placeholder="18+"
                  required
                />
              </div>
            )}
            {isSignup && googleProfile && (
              <>
                <div className="form-grid">
                  <Field
                    id="firstName"
                    label="First name"
                    autoComplete="given-name"
                    minLength={2}
                    maxLength={50}
                    pattern="[\p{L}][\p{L}\p{M} ’'-]{1,49}"
                    title="Use 2–50 letters, spaces, apostrophes, or hyphens."
                    value={googleNames.firstName}
                    onChange={(event) =>
                      setGoogleNames((names) => ({
                        ...names,
                        firstName: event.target.value,
                      }))
                    }
                    required
                  />
                  <Field
                    id="lastName"
                    label="Last name"
                    autoComplete="family-name"
                    minLength={2}
                    maxLength={50}
                    pattern="[\p{L}][\p{L}\p{M} ’'-]{1,49}"
                    title="Use 2–50 letters, spaces, apostrophes, or hyphens."
                    value={googleNames.lastName}
                    onChange={(event) =>
                      setGoogleNames((names) => ({
                        ...names,
                        lastName: event.target.value,
                      }))
                    }
                    required
                  />
                  <Field
                    id="phone"
                    label="Rwanda phone number"
                    type="tel"
                    autoComplete="tel"
                    inputMode="tel"
                    minLength={10}
                    maxLength={16}
                    pattern="(?:\+250 ?|0)7[0-9]{2} ?[0-9]{3} ?[0-9]{3}"
                    title="Use +250 7XX XXX XXX or 07XX XXX XXX."
                    placeholder="+250 788 123 456"
                    required
                  />
                  <Field
                    id="age"
                    label="Age"
                    type="number"
                    min={18}
                    max={120}
                    step={1}
                    inputMode="numeric"
                    placeholder="18+"
                    required
                  />
                </div>
              </>
            )}
            {!googleProfile && (
              <>
                <Field
                  id={`${role}-email`}
                  name="email"
                  label="Email address"
                  type="email"
                  autoComplete="email"
                  maxLength={254}
                  placeholder="you@example.com"
                  required
                />
                <Field
                  id={`${role}-password`}
                  name="password"
                  label={isSignup ? "Create password" : "Password"}
                  type="password"
                  autoComplete={isSignup ? "new-password" : "current-password"}
                  minLength={8}
                  maxLength={128}
                  pattern={
                    isSignup
                      ? "(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[^A-Za-z0-9]).{8,128}"
                      : undefined
                  }
                  title={
                    isSignup
                      ? "Use 8–128 characters with uppercase, lowercase, a number, and a symbol."
                      : undefined
                  }
                  placeholder={
                    isSignup
                      ? "8+ characters with upper/lowercase, number and symbol"
                      : "Your password"
                  }
                  required
                />
              </>
            )}
            {isSignup && (
              <>
                {!googleProfile && (
                  <Field
                    id="confirmPassword"
                    name="confirmPassword"
                    label="Confirm password"
                    type="password"
                    autoComplete="new-password"
                    minLength={8}
                    maxLength={128}
                    required
                  />
                )}
                <div className="terms-row">
                  <input
                    id={`${role}-terms`}
                    name="termsAccepted"
                    type="checkbox"
                    value="true"
                    required
                  />
                  <label htmlFor={`${role}-terms`}>
                    I agree to the{" "}
                    <button
                      type="button"
                      className="inline-link"
                      onClick={() => navigate("terms")}
                    >
                      Terms &amp; Conditions
                    </button>
                  </label>
                </div>
              </>
            )}
            {error && (
              <div className="form-error" role="alert">
                {error}
              </div>
            )}
            <button className="btn full form-submit">
              {googleProfile
                ? isProvider
                  ? "Create owner / agent account"
                  : "Create renter account"
                : isSignup
                  ? isProvider
                    ? "Create owner / agent account"
                    : "Create renter account"
                  : isProvider
                    ? "Sign in as owner / agent"
                    : "Sign in"}
            </button>
          </form>
          {isSignup ? (
            <p className="form-foot">
              Already have an account?{" "}
              <button
                className="text-link"
                onClick={() => navigate(isProvider ? "owner-login" : "signin")}
              >
                Sign in
              </button>
            </p>
          ) : (
            <p className="form-foot">
              {isProvider ? "New owner or agent?" : "New to E-wawe?"}{" "}
              <button
                className="text-link"
                onClick={() =>
                  navigate(isProvider ? "signup-provider" : "signup-renter")
                }
              >
                Create an account
              </button>
            </p>
          )}
        </div>
      </section>
    </main>
  );
}

// Field keeps form labels and inputs consistently connected and accessible.
function Field({ id, name = id, label, type = "text", ...props }) {
  return (
    <div className="form-row">
      <label htmlFor={id}>{label}</label>
      <input id={id} name={name} type={type} {...props} />
    </div>
  );
}

// Dashboard loads provider analytics, accepts photos, and publishes listings.
function Dashboard({ user, navigate, flash }) {
  const [dashboard, setDashboard] = useState({
    stats: { activeListings: 0, views: 0, inquiries: 0, contactClicks: 0 },
    properties: [],
    inquiries: [],
    plans: [],
    plan: {
      id: "free",
      name: "Free",
      maxListings: 1,
      analytics: false,
      inquiryManagement: false,
    },
    subscription: { status: "active", renewsAt: null },
  });
  const [loading, setLoading] = useState(true);
  const [files, setFiles] = useState([]);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [billingPlan, setBillingPlan] = useState("");
  const canManage = ["owner", "agent"].includes(user?.role);
  const loadDashboard = useCallback(
    () =>
      request("/dashboard")
        .then(setDashboard)
        .catch((error) => {
          if (/sign in|permission/i.test(error.message))
            navigate("owner-login");
          else setError(error.message);
        })
        .finally(() => setLoading(false)),
    [navigate],
  );
  useEffect(() => {
    if (canManage) loadDashboard();
    else {
      setLoading(false);
      navigate("owner-login");
    }
  }, [canManage, loadDashboard, navigate]);

  async function saveProperty(event) {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    setSaving(true);
    setError("");
    try {
      const values = Object.fromEntries(new FormData(form).entries());
      const amenities = String(values.amenities || "")
        .split(",")
        .map((item) => item.trim())
        .filter(Boolean);
      const data = {
        ...values,
        rent: Number(values.rent),
        bedrooms: Number(values.bedrooms),
        bathrooms: Number(values.bathrooms),
        areaSqm: Number(values.areaSqm),
        amenities,
        images: files,
      };
      await request("/properties", {
        method: "POST",
        body: JSON.stringify(data),
      });
      form.reset();
      setFiles([]);
      await loadDashboard();
      flash("Your property listing has been published.");
      document
        .getElementById("properties")
        ?.scrollIntoView({ behavior: "smooth" });
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  async function beginCheckout(planId) {
    setBillingPlan(planId);
    setError("");
    try {
      const { checkoutUrl } = await request("/billing/checkout", {
        method: "POST",
        body: JSON.stringify({ planId }),
      });
      window.location.assign(checkoutUrl);
    } catch (err) {
      setError(err.message);
    } finally {
      setBillingPlan("");
    }
  }

  async function readImages(fileList) {
    const selected = Array.from(fileList || []);
    if (selected.length + files.length > PHOTO_LIMIT) {
      setError(`Add up to ${PHOTO_LIMIT} photos.`);
      return;
    }
    if (
      selected.some(
        (file) =>
          !["image/jpeg", "image/png", "image/webp"].includes(file.type) ||
          file.size > MAX_PHOTO_BYTES,
      )
    ) {
      setError("Use JPG, PNG, or WebP photos up to 2 MB each.");
      return;
    }
    const dataUrls = await Promise.all(
      selected.map(
        (file) =>
          new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(file);
          }),
      ),
    );
    setFiles((current) => [...current, ...dataUrls]);
    setError("");
  }

  if (!canManage) return null;
  return (
    <main className="dash-shell">
      <aside className="sidebar">
        <button className="brand" onClick={() => navigate("home")}>
          E-wawe<span>.</span>
        </button>
        <a href="#overview">Overview</a>
        <a href="#properties">My properties</a>
        <a href={dashboard.plan.inquiryManagement ? "#inquiries" : "#plans"}>
          Inquiries
        </a>
        <a href="#plans">Plans &amp; billing</a>
        <a href="#profile">Profile &amp; settings</a>
        <button onClick={() => navigate("listings")}>View renter site ↗</button>
      </aside>
      <section className="dash-main">
        {error && (
          <div className="form-error" role="alert">
            {error}
          </div>
        )}
        <div id="overview" className="dash-top">
          <div>
            <div className="eyebrow">Owner &amp; agent workspace</div>
            <h1 className="page-title">
              Good morning, {user?.firstName || "there"}.
            </h1>
            <p className="muted">
              Here’s what’s happening with your properties.
            </p>
          </div>
          <a className="btn" href="#new-property">
            ＋ Add a property
          </a>
        </div>
        <div className="stats">
          <Stat
            label="Active listings"
            value={dashboard.stats.activeListings}
            note={`of ${dashboard.plan.maxListings ?? "unlimited"} available`}
          />
          {dashboard.plan.analytics && (
            <Stat
              label="Listing views"
              value={dashboard.stats.views}
              note="All time"
            />
          )}
          {dashboard.plan.inquiryManagement && (
            <Stat
              label="Inquiries"
              value={dashboard.stats.inquiries}
              note="Contact requests"
            />
          )}
          {dashboard.plan.analytics && (
            <Stat
              label="Contact requests"
              value={dashboard.stats.contactClicks}
              note="Renters reached out"
            />
          )}
        </div>
        {dashboard.plan.analytics ? (
          <section className="dash-section">
            <div className="section-head">
              <div>
                <h2>Listing performance</h2>
                <p>Views and renter interest across your properties.</p>
              </div>
            </div>
            <PerformanceChart properties={dashboard.properties} />
          </section>
        ) : (
          <div className="upgrade-callout">
            <div>
              <strong>Unlock listing insights</strong>
              <p>
                Growth adds views, renter inquiries, and one promoted listing.
              </p>
            </div>
            <a className="btn" href="#plans">
              Explore plans
            </a>
          </div>
        )}
        <section className="dash-section" id="properties">
          <div className="section-head">
            <div>
              <h2>Your properties</h2>
              <p>Manage listings and keep an eye on their performance.</p>
            </div>
            <a className="text-link" href="#new-property">
              Add a listing →
            </a>
          </div>
          {loading ? (
            <p className="muted">Loading your properties…</p>
          ) : dashboard.properties.length ? (
            <div className="table-scroll">
              <table className="table">
                <thead>
                  <tr>
                    <th>Property</th>
                    <th>Status</th>
                    <th>Monthly rent</th>
                    <th>Area</th>
                    {dashboard.plan.analytics && <th>Views</th>}
                    {dashboard.plan.analytics && <th>Contact requests</th>}
                  </tr>
                </thead>
                <tbody>
                  {dashboard.properties.map((item) => (
                    <tr key={item.id}>
                      <td>
                        <strong>{item.title}</strong>
                        <br />
                        <small>{item.neighborhood}, Kigali</small>
                      </td>
                      <td>
                        <span className="status">Active</span>
                      </td>
                      <td>{usd.format(item.rent)}</td>
                      <td>{item.areaSqm} m²</td>
                      {dashboard.plan.analytics && <td>{item.views || 0}</td>}
                      {dashboard.plan.analytics && (
                        <td>{item.contactClicks || 0}</td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="empty-state">
              No properties yet. Add your first Kigali home below.
            </div>
          )}
        </section>
        {dashboard.plan.inquiryManagement && (
          <section className="dash-section" id="inquiries">
            <div className="section-head">
              <div>
                <h2>Recent inquiries</h2>
                <p>See which listings are getting renter interest.</p>
              </div>
            </div>
            {dashboard.inquiries.length ? (
              <div className="inquiry-list">
                {dashboard.inquiries.map((item) => (
                  <div className="inquiry-row" key={item.id}>
                    <span>
                      <strong>{item.propertyTitle}</strong>
                      <small>{new Date(item.createdAt).toLocaleString()}</small>
                    </span>
                    <span className="status">Contact revealed</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="empty-state">No renter contact requests yet.</div>
            )}
          </section>
        )}
        <section className="dash-section" id="plans">
          <div className="section-head">
            <div>
              <h2>Plans &amp; billing</h2>
              <p>Choose the monthly tools that fit your property portfolio.</p>
            </div>
          </div>
          <div className="plan-grid">
            {dashboard.plans.map((plan) => (
              <article
                className={`plan-card${dashboard.plan.id === plan.id ? " plan-current" : ""}`}
                key={plan.id}
              >
                <span className="eyebrow">
                  {dashboard.plan.id === plan.id
                    ? "Current plan"
                    : "Monthly plan"}
                </span>
                <h3>{plan.name}</h3>
                <p>{plan.description}</p>
                <div className="plan-price">
                  {plan.monthlyPrice === 0
                    ? "Free"
                    : usd.format(plan.monthlyPrice)}
                  {plan.monthlyPrice > 0 && <small> / month</small>}
                </div>
                <ul>
                  {plan.features.map((feature) => (
                    <li key={feature}>{feature}</li>
                  ))}
                </ul>
                {plan.id === dashboard.plan.id ? (
                  <span className="status">Active</span>
                ) : plan.id === "free" ? (
                  <span className="muted">Included</span>
                ) : (
                  <button
                    className="btn"
                    disabled={
                      Boolean(billingPlan) || dashboard.plan.id !== "free"
                    }
                    onClick={() => beginCheckout(plan.id)}
                  >
                    {billingPlan === plan.id
                      ? "Opening secure checkout…"
                      : dashboard.plan.id !== "free"
                        ? "Plan change unavailable"
                        : "Choose plan"}
                  </button>
                )}
              </article>
            ))}
          </div>
          <p className="billing-note">
            Paid plans renew monthly through Flutterwave. Recurring billing
            requires a card. Use the cancellation link in a Flutterwave payment
            reminder email to stop renewals; access changes when Flutterwave
            confirms cancellation. Payments appear here only after server
            verification.
          </p>
        </section>
        <section className="dash-section profile-panel" id="profile">
          <div className="section-head">
            <div>
              <h2>Profile &amp; settings</h2>
              <p>Account details connected to your listings.</p>
            </div>
          </div>
          <div className="profile-grid">
            <div>
              <span>Account holder</span>
              <strong>
                {user?.firstName} {user?.lastName}
              </strong>
            </div>
            <div>
              <span>Account type</span>
              <strong>
                {user?.role === "agent" ? "Property agent" : "Property owner"}
              </strong>
            </div>
            <div>
              <span>Email</span>
              <strong>{user?.email}</strong>
            </div>
            <div>
              <span>Phone</span>
              <strong>{user?.phone}</strong>
            </div>
          </div>
        </section>
        <section className="dash-section" id="new-property">
          <div className="section-head">
            <div>
              <h2>Add a property</h2>
              <p>Share the details renters need to find their next home.</p>
            </div>
          </div>
          <form className="panel listing-form" onSubmit={saveProperty}>
            <div className="form-row">
              <label htmlFor="title">Property title</label>
              <input
                id="title"
                name="title"
                minLength={5}
                maxLength={100}
                required
                placeholder="e.g. Sunlit modern townhouse"
              />
            </div>
            <div className="form-row">
              <label htmlFor="description">Property description</label>
              <textarea
                id="description"
                name="description"
                minLength={30}
                maxLength={5000}
                rows={4}
                required
                placeholder="Describe the home's features, setting, and lease details."
              />
            </div>
            <div className="form-grid">
              <div className="form-row">
                <label htmlFor="neighborhood">Kigali neighborhood</label>
                <select
                  id="neighborhood"
                  name="neighborhood"
                  required
                  defaultValue=""
                >
                  <option value="" disabled>
                    Choose a neighborhood
                  </option>
                  {neighborhoods.map((item) => (
                    <option key={item}>{item}</option>
                  ))}
                </select>
              </div>
              <div className="form-row">
                <label htmlFor="rent">Monthly rent (USD)</label>
                <input
                  id="rent"
                  name="rent"
                  type="number"
                  min="1"
                  max="10000000"
                  step="1"
                  required
                />
              </div>
              <div className="form-row">
                <label htmlFor="bedrooms">Bedrooms</label>
                <input
                  id="bedrooms"
                  name="bedrooms"
                  type="number"
                  min="0"
                  max="30"
                  step="1"
                  required
                />
              </div>
              <div className="form-row">
                <label htmlFor="bathrooms">Bathrooms</label>
                <input
                  id="bathrooms"
                  name="bathrooms"
                  type="number"
                  min="0"
                  max="30"
                  step="0.5"
                  required
                />
              </div>
              <div className="form-row">
                <label htmlFor="areaSqm">Floor area (m²)</label>
                <input
                  id="areaSqm"
                  name="areaSqm"
                  type="number"
                  min="10"
                  max="10000"
                  step="1"
                  required
                />
              </div>
              <div className="form-row">
                <label htmlFor="propertyType">Property type</label>
                <select
                  id="propertyType"
                  name="propertyType"
                  required
                  defaultValue=""
                >
                  <option value="" disabled>
                    Choose a type
                  </option>
                  {propertyTypes.map((item) => (
                    <option key={item}>{item}</option>
                  ))}
                </select>
              </div>
              <div className="form-row">
                <label htmlFor="availableDate">Available from</label>
                <input
                  id="availableDate"
                  name="availableDate"
                  type="date"
                  required
                />
              </div>
              <div className="form-row">
                <label htmlFor="leaseTerm">Lease term</label>
                <input
                  id="leaseTerm"
                  name="leaseTerm"
                  minLength={2}
                  maxLength={50}
                  required
                  placeholder="e.g. 12 months"
                />
              </div>
            </div>
            <div className="form-row">
              <label htmlFor="amenities">Amenities (comma separated)</label>
              <input
                id="amenities"
                name="amenities"
                maxLength={500}
                placeholder="Parking, balcony, security"
              />
            </div>
            <div className="form-row">
              <label htmlFor="photos">Property photos (up to 5)</label>
              <input
                id="photos"
                type="file"
                accept="image/jpeg,image/png,image/webp"
                multiple
                onChange={(event) => readImages(event.target.files)}
              />
              <small className="muted">
                JPG, PNG, or WebP · up to 2 MB per image
              </small>
            </div>
            {files.length > 0 && (
              <div className="photo-preview">
                {files.map((src, index) => (
                  <img
                    key={`${src.slice(0, 40)}-${index}`}
                    src={src}
                    alt={`Selected property ${index + 1}`}
                  />
                ))}
              </div>
            )}
            {error && (
              <div className="form-error" role="alert">
                {error}
              </div>
            )}
            <button className="btn" disabled={saving || files.length === 0}>
              {saving ? "Saving listing…" : "Publish property"}
            </button>
          </form>
        </section>
      </section>
    </main>
  );
}

// Stat displays one provider dashboard metric.
function Stat({ label, value, note }) {
  return (
    <div className="stat">
      <span>{label}</span>
      <strong>{value.toLocaleString()}</strong>
      <small>{note}</small>
    </div>
  );
}

// PerformanceChart compares view counts across a provider's first six listings.
function PerformanceChart({ properties }) {
  const values = properties.map((property) => Number(property.views || 0));
  const max = Math.max(1, ...values);
  return (
    <div className="chart">
      <div className="bars">
        {(values.length ? values : [0, 0, 0, 0, 0, 0])
          .slice(0, 6)
          .map((value, index) => (
            <i
              key={index}
              style={{ height: `${Math.max(5, (value / max) * 100)}%` }}
              title={`${value} views`}
            />
          ))}
      </div>
      <div className="chart-labels">
        <span>Your listings</span>
        <span>Views</span>
      </div>
    </div>
  );
}

// Terms displays the prototype's account and listing guidelines.
function Terms({ navigate }) {
  return (
    <main className="page-wrap">
      <div className="eyebrow">E-wawe</div>
      <h1 className="page-title">Terms &amp; Conditions</h1>
      <section className="panel terms-copy">
        <h2>Using E-wawe</h2>
        <p>
          Provide accurate information and use E-wawe to browse, list, and
          inquire about long-term rental properties respectfully and lawfully.
        </p>
        <h2>Accounts and listings</h2>
        <p>
          Keep your sign-in details private. Owners and agents are responsible
          for the accuracy of property descriptions, photographs, rent,
          availability, and contact details.
        </p>
        <h2>Property inquiries</h2>
        <p>
          Verify property details and lease terms directly with the listing
          contact before making rental decisions.
        </p>
        <h2>Privacy</h2>
        <p>
          Account details support your platform experience and communications
          about listings.
        </p>
        <button className="btn" onClick={() => navigate("signup-renter")}>
          Return to sign up
        </button>
      </section>
    </main>
  );
}

// Footer provides the brand link and terms navigation.
function Footer({ navigate }) {
  return (
    <footer className="site-footer">
      <div>
        <button className="brand" onClick={() => navigate("home")}>
          E-wawe<span>.</span>
        </button>
        <p>Long-term homes, thoughtfully found in Kigali.</p>
      </div>
      <div>
        © 2026 E-wawe ·{" "}
        <button onClick={() => navigate("terms")}>
          Terms &amp; Conditions
        </button>
      </div>
    </footer>
  );
}

export default App;

import http from "node:http";
import {
  randomBytes,
  randomUUID,
  scryptSync,
  timingSafeEqual,
} from "node:crypto";
import { readFileSync, renameSync, writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import path from "node:path";
import { OAuth2Client } from "google-auth-library";

// Resolve app storage paths and configure the API process.
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const dataDir = path.join(root, "data");
// Read optional local secrets without adding a runtime package dependency.
try {
  const envFile = readFileSync(path.join(root, ".env"), "utf8");
  for (const line of envFile.split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if (match && process.env[match[1]] === undefined) {
      const value = match[2].replace(/^(["'])(.*)\1$/, "$2");
      process.env[match[1]] = value;
    }
  }
} catch (error) {
  if (error.code !== "ENOENT") throw error;
}
const sessions = new Map();
const googleAuthClient = new OAuth2Client();
const PORT = Number(process.env.API_PORT || 3002);
const MAX_BODY_BYTES = 16 * 1024 * 1024;
const BILLING_CURRENCY = "USD";
const PUBLIC_APP_URL = process.env.PUBLIC_APP_URL || "http://localhost:5173";
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const namePattern = /^[\p{L}][\p{L}\p{M} '\u2019-]{1,49}$/u;
const rwandaPhonePattern = /^(?:\+250 ?|0)7\d{2} ?\d{3} ?\d{3}$/;
const passwordPattern =
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).{8,128}$/;

// Monthly provider plans and the capabilities each plan unlocks.
const plans = {
  free: {
    id: "free",
    name: "Free",
    description: "For a single property and a simple way to get started.",
    monthlyPrice: 0,
    currency: BILLING_CURRENCY,
    maxListings: 1,
    promotedSlots: 0,
    analytics: false,
    inquiryManagement: false,
    features: ["1 active listing", "Renter contact button"],
  },
  growth: {
    id: "growth",
    name: "Growth",
    description: "For independent owners and small property portfolios.",
    monthlyPrice: 19,
    currency: BILLING_CURRENCY,
    maxListings: 5,
    promotedSlots: 1,
    analytics: true,
    inquiryManagement: true,
    features: [
      "Up to 5 active listings",
      "1 promoted listing",
      "Listing analytics",
      "Inquiry management",
    ],
  },
  professional: {
    id: "professional",
    name: "Professional",
    description: "For agents and growing property portfolios.",
    monthlyPrice: 49,
    currency: BILLING_CURRENCY,
    maxListings: null,
    promotedSlots: 5,
    analytics: true,
    inquiryManagement: true,
    features: [
      "Unlimited active listings",
      "Up to 5 promoted listings",
      "Listing analytics",
      "Inquiry management",
    ],
  },
};

// Load one JSON collection, treating a missing data file as an empty collection.
function load(file) {
  try {
    return JSON.parse(readFileSync(path.join(dataDir, file), "utf8"));
  } catch (error) {
    if (error.code === "ENOENT") return [];
    throw error;
  }
}

// Write JSON through a temporary file so an interrupted write is less likely to corrupt data.
function save(file, value) {
  const target = path.join(dataDir, file);
  const temporary = `${target}.${process.pid}.tmp`;
  writeFileSync(temporary, `${JSON.stringify(value, null, 2)}\n`, "utf8");
  renameSync(temporary, target);
}

// Send JSON with headers that prevent caching and content-type sniffing.
function json(res, status, body) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
  });
  res.end(JSON.stringify(body));
}

// Read and validate a bounded JSON request body.
async function readBody(req) {
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY_BYTES)
      throw Object.assign(
        new Error("Request is too large. Reduce the image size and try again."),
        {
          status: 413,
        },
      );
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}");
  } catch {
    throw Object.assign(new Error("The request body must be valid JSON."), {
      status: 400,
    });
  }
}

// Remove credential fields before returning a user object to the browser.
function publicUser(user) {
  const { passwordSalt, passwordHash, googleSub, ...safe } = user;
  return safe;
}

// Verify Google's signed ID token and only use claims returned by Google.
async function verifyGoogleCredential(credential) {
  const clientId = process.env.VITE_GOOGLE_CLIENT_ID;
  if (!clientId) {
    throw Object.assign(
      new Error(
        "Google sign-in is not configured. Add the Google client ID to .env.",
      ),
      { status: 503 },
    );
  }
  if (typeof credential !== "string" || credential.length > 10000) {
    throw Object.assign(new Error("Google could not verify this sign-in."), {
      status: 401,
    });
  }
  try {
    const ticket = await googleAuthClient.verifyIdToken({
      idToken: credential,
      audience: clientId,
    });
    const payload = ticket.getPayload();
    if (!payload?.sub || !payload.email || payload.email_verified !== true) {
      throw new Error("Google account email must be verified.");
    }
    const [fallbackFirstName = "", ...remainingName] = String(
      payload.name || "",
    )
      .trim()
      .split(/\s+/);
    return {
      googleSub: payload.sub,
      email: payload.email.trim().toLowerCase(),
      firstName: payload.given_name || fallbackFirstName,
      lastName: payload.family_name || remainingName.join(" "),
    };
  } catch (error) {
    if (error.status) throw error;
    throw Object.assign(new Error("Google could not verify this sign-in."), {
      status: 401,
    });
  }
}

// Issue the platform's own session token after a password or Google login.
function createSession(user) {
  const token = randomBytes(32).toString("hex");
  sessions.set(token, user.id);
  return token;
}

// Resolve an in-memory bearer token to its account record.
function currentUser(req) {
  const token = req.headers.authorization?.replace(/^Bearer\s+/i, "");
  const userId = token && sessions.get(token);
  return userId
    ? load("users.json").find((user) => user.id === userId) || null
    : null;
}

// Enforce sign-in and role permissions for provider-only endpoints.
function requireRole(req, res, roles = []) {
  const user = currentUser(req);
  if (!user) {
    json(res, 401, { error: "Please sign in to continue." });
    return null;
  }
  if (roles.length && !roles.includes(user.role)) {
    json(res, 403, {
      error: "This account does not have permission for that action.",
    });
    return null;
  }
  return user;
}

// Hide private ownership/contact fields from public listing responses.
function safeProperty(property, includeContact = false) {
  const { ownerId, contact, ...visible } = property;
  const ownerPlan = ownerId ? activePlanFor(ownerId) : plans.free;
  visible.promoted = Boolean(property.promoted && ownerPlan.promotedSlots);
  return includeContact
    ? { ...visible, contact }
    : { ...visible, contactRole: contact?.role || "owner" };
}

// Return the provider's saved plan, or a free plan for older accounts.
function subscriptionFor(userId) {
  const subscriptions = load("subscriptions.json");
  return (
    subscriptions.find((subscription) => subscription.userId === userId) || {
      id: null,
      userId,
      planId: "free",
      status: "active",
      billingCycle: "monthly",
      startedAt: null,
      renewsAt: null,
      paymentMode: "none",
    }
  );
}

// Create a free-plan record for every new owner or agent.
function startFreeSubscription(userId) {
  const subscriptions = load("subscriptions.json");
  if (subscriptions.some((subscription) => subscription.userId === userId))
    return;
  subscriptions.push({
    id: randomUUID(),
    userId,
    planId: "free",
    status: "active",
    billingCycle: "monthly",
    startedAt: new Date().toISOString(),
    renewsAt: null,
    paymentMode: "none",
  });
  save("subscriptions.json", subscriptions);
}

// Verify a hosted checkout with Flutterwave before granting paid features.
async function verifyCheckout(user, transactionId, txRef) {
  const pendingPayments = load("pendingPayments.json");
  const pending = pendingPayments.find(
    (payment) =>
      payment.userId === user.id &&
      payment.txRef === txRef &&
      !payment.completedAt,
  );
  if (!pending) {
    const current = subscriptionFor(user.id);
    if (current.lastTransactionId === String(transactionId)) {
      return {
        subscription: current,
        plan: plans[current.planId] || plans.free,
      };
    }
    throw Object.assign(new Error("This billing attempt has expired."), {
      status: 404,
    });
  }

  const transaction = await flutterwaveRequest(
    `/transactions/${encodeURIComponent(transactionId)}/verify`,
  );
  const paymentPlan = String(transaction.payment_plan || "");
  const customerEmail = String(transaction.customer?.email || "").toLowerCase();
  if (
    transaction.status !== "successful" ||
    transaction.tx_ref !== pending.txRef ||
    Number(transaction.amount) !== pending.amount ||
    String(transaction.currency).toUpperCase() !== pending.currency ||
    customerEmail !== user.email ||
    paymentPlan !== pending.providerPlanId
  ) {
    throw Object.assign(
      new Error("Flutterwave could not verify this subscription payment."),
      { status: 402 },
    );
  }

  const subscription = activatePaidPlan(
    user.id,
    pending.planId,
    transaction.id,
    pending.providerPlanId,
  );
  pending.completedAt = new Date().toISOString();
  pending.transactionId = String(transaction.id);
  save("pendingPayments.json", pendingPayments);
  return { subscription, plan: plans[pending.planId] };
}

// Resolve paid capabilities only from a confirmed Flutterwave subscription.
function activePlanFor(userId) {
  const subscription = subscriptionFor(userId);
  const plan = plans[subscription.planId] || plans.free;
  if (
    plan.id !== "free" &&
    (subscription.status !== "active" ||
      (subscription.renewsAt && Date.parse(subscription.renewsAt) < Date.now()))
  )
    return plans.free;
  return plan;
}

// Send server-only requests to Flutterwave without exposing merchant keys.
async function flutterwaveRequest(endpoint, options = {}) {
  const secretKey = process.env.FLW_SECRET_KEY;
  if (!secretKey) {
    throw Object.assign(
      new Error("Flutterwave billing is not configured yet."),
      { status: 503 },
    );
  }
  const response = await fetch(`https://api.flutterwave.com/v3${endpoint}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${secretKey}`,
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
    signal: AbortSignal.timeout(15000),
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok || result.status !== "success") {
    throw Object.assign(
      new Error(result.message || "Flutterwave could not process billing."),
      { status: 502 },
    );
  }
  return result.data;
}

// Save a paid plan only after Flutterwave confirms its first charge.
function activatePaidPlan(userId, planId, transactionId, providerPlanId) {
  const subscriptions = load("subscriptions.json");
  const existing = subscriptions.findIndex(
    (subscription) => subscription.userId === userId,
  );
  const startedAt = new Date();
  const renewsAt = new Date(startedAt);
  renewsAt.setMonth(renewsAt.getMonth() + 1);
  const subscription = {
    id: existing >= 0 ? subscriptions[existing].id : randomUUID(),
    userId,
    planId,
    status: "active",
    billingCycle: "monthly",
    startedAt: startedAt.toISOString(),
    renewsAt: renewsAt.toISOString(),
    paymentMode: "flutterwave",
    providerPlanId: String(providerPlanId),
    lastTransactionId: String(transactionId),
  };
  if (existing >= 0) subscriptions[existing] = subscription;
  else subscriptions.push(subscription);
  save("subscriptions.json", subscriptions);
  return subscription;
}

// Compare webhook secrets without leaking length-dependent equality details.
function secureStringEqual(left, right) {
  if (typeof left !== "string" || typeof right !== "string") return false;
  const leftBytes = Buffer.from(left);
  const rightBytes = Buffer.from(right);
  return (
    leftBytes.length === rightBytes.length &&
    timingSafeEqual(leftBytes, rightBytes)
  );
}

// Validate registration identity, password, contact, role, and terms acceptance.
function validateSignup(body) {
  const errors = [];
  const firstName = String(body.firstName || "").trim();
  const lastName = String(body.lastName || "").trim();
  const phone = String(body.phone || "").trim();
  const email = String(body.email || "")
    .trim()
    .toLowerCase();
  const age = Number(body.age);
  const role = body.role;
  if (!namePattern.test(firstName))
    errors.push(
      "Enter a valid first name using 2–50 letters, spaces, apostrophes, or hyphens.",
    );
  if (!namePattern.test(lastName))
    errors.push(
      "Enter a valid last name using 2–50 letters, spaces, apostrophes, or hyphens.",
    );
  if (!rwandaPhonePattern.test(phone))
    errors.push("Enter a Rwanda phone number, such as +250 788 123 456.");
  if (!Number.isInteger(age) || age < 18 || age > 120)
    errors.push("You must be at least 18 and enter a valid age.");
  if (!emailPattern.test(email) || email.length > 254)
    errors.push("Enter a valid email address.");
  if (!passwordPattern.test(String(body.password || "")))
    errors.push(
      "Use 8–128 password characters with uppercase, lowercase, a number, and a symbol.",
    );
  if (body.password !== body.confirmPassword)
    errors.push("Your passwords do not match.");
  if (body.termsAccepted !== true)
    errors.push("Accept the Terms & Conditions to create an account.");
  if (!["renter", "owner", "agent"].includes(role))
    errors.push("Choose renter, owner, or agent account type.");
  return { errors, value: { firstName, lastName, phone, email, age, role } };
}

// Validate the extra platform details required for a Google-based signup.
function validateGoogleSignup(body, identity) {
  const errors = [];
  const firstName = String(body.firstName || identity.firstName || "").trim();
  const lastName = String(body.lastName || identity.lastName || "").trim();
  const phone = String(body.phone || "").trim();
  const age = Number(body.age);
  const role = body.role;
  if (!namePattern.test(firstName))
    errors.push("Enter a valid first name from your Google profile.");
  if (!namePattern.test(lastName))
    errors.push("Enter a valid last name from your Google profile.");
  if (!rwandaPhonePattern.test(phone))
    errors.push("Enter a Rwanda phone number, such as +250 788 123 456.");
  if (!Number.isInteger(age) || age < 18 || age > 120)
    errors.push("You must be at least 18 and enter a valid age.");
  if (body.termsAccepted !== true)
    errors.push("Accept the Terms & Conditions to create an account.");
  if (!["renter", "owner", "agent"].includes(role))
    errors.push("Choose renter, owner, or agent account type.");
  return {
    errors,
    value: { firstName, lastName, phone, age, role, email: identity.email },
  };
}

// Find a listing in the local JSON property collection.
function findProperty(id) {
  return load("properties.json").find((property) => property.id === id);
}

// API route table: authentication, public listings, contact reveal, and provider tools.
const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
    const pathname = url.pathname;
    if (req.method === "OPTIONS") {
      res.writeHead(204);
      res.end();
      return;
    }
    if (pathname === "/api/health" && req.method === "GET") {
      json(res, 200, { ok: true });
      return;
    }

    if (pathname === "/api/plans" && req.method === "GET") {
      json(res, 200, { plans: Object.values(plans) });
      return;
    }

    if (pathname === "/api/auth/google/profile" && req.method === "POST") {
      const body = await readBody(req);
      const identity = await verifyGoogleCredential(body.credential);
      json(res, 200, { identity });
      return;
    }

    if (pathname === "/api/auth/google/signup" && req.method === "POST") {
      const body = await readBody(req);
      const identity = await verifyGoogleCredential(body.credential);
      const { errors, value } = validateGoogleSignup(body, identity);
      if (errors.length) {
        json(res, 400, { error: errors[0], errors });
        return;
      }
      const users = load("users.json");
      if (users.some((user) => user.email === identity.email)) {
        json(res, 409, {
          error:
            "An account with this Google email already exists. Sign in instead.",
        });
        return;
      }
      const user = {
        id: randomUUID(),
        ...value,
        googleSub: identity.googleSub,
        authMethod: "google",
        createdAt: new Date().toISOString(),
      };
      users.push(user);
      save("users.json", users);
      if (user.role === "owner" || user.role === "agent") {
        startFreeSubscription(user.id);
      }
      json(res, 201, { token: createSession(user), user: publicUser(user) });
      return;
    }

    if (pathname === "/api/auth/google/login" && req.method === "POST") {
      const body = await readBody(req);
      const identity = await verifyGoogleCredential(body.credential);
      if (!["renter", "provider"].includes(body.accountType)) {
        json(res, 400, { error: "Choose a renter or provider sign-in page." });
        return;
      }
      const users = load("users.json");
      const user =
        users.find((entry) => entry.googleSub === identity.googleSub) ||
        users.find((entry) => entry.email === identity.email);
      if (!user) {
        json(res, 404, {
          error:
            "No E-wawe account is linked to this Google account. Create an account first.",
        });
        return;
      }
      if (user.googleSub && user.googleSub !== identity.googleSub) {
        json(res, 409, {
          error: "This email is linked to a different Google account.",
        });
        return;
      }
      const isProvider = ["owner", "agent"].includes(user.role);
      if ((body.accountType === "provider") !== isProvider) {
        json(res, 403, {
          error: isProvider
            ? "Use the owner / agent sign-in page for this account."
            : "Use the renter sign-in page for this account.",
        });
        return;
      }
      if (!user.googleSub) {
        user.googleSub = identity.googleSub;
        user.authMethod = user.passwordHash ? "password+google" : "google";
        save("users.json", users);
      }
      json(res, 200, { token: createSession(user), user: publicUser(user) });
      return;
    }

    if (pathname === "/api/auth/signup" && req.method === "POST") {
      const body = await readBody(req);
      const { errors, value } = validateSignup(body);
      if (errors.length) {
        json(res, 400, { error: errors[0], errors });
        return;
      }
      const users = load("users.json");
      if (users.some((user) => user.email === value.email)) {
        json(res, 409, {
          error: "An account with this email already exists. Sign in instead.",
        });
        return;
      }
      const salt = randomBytes(16).toString("hex");
      const user = {
        id: randomUUID(),
        ...value,
        passwordSalt: salt,
        passwordHash: scryptSync(body.password, salt, 64).toString("hex"),
        createdAt: new Date().toISOString(),
      };
      users.push(user);
      save("users.json", users);
      if (user.role === "owner" || user.role === "agent") {
        startFreeSubscription(user.id);
      }
      json(res, 201, { token: createSession(user), user: publicUser(user) });
      return;
    }

    if (pathname === "/api/auth/login" && req.method === "POST") {
      const body = await readBody(req);
      const email = String(body.email || "")
        .trim()
        .toLowerCase();
      const password = String(body.password || "");
      if (!emailPattern.test(email) || !password) {
        json(res, 400, { error: "Enter a valid email and password." });
        return;
      }
      const user = load("users.json").find((entry) => entry.email === email);
      const attempted = user?.passwordSalt
        ? scryptSync(password, user.passwordSalt, 64)
        : randomBytes(64);
      const expected = user?.passwordHash
        ? Buffer.from(user.passwordHash, "hex")
        : randomBytes(64);
      if (
        !user ||
        expected.length !== attempted.length ||
        !timingSafeEqual(expected, attempted)
      ) {
        json(res, 401, { error: "Email or password is incorrect." });
        return;
      }
      const token = randomBytes(32).toString("hex");
      sessions.set(token, user.id);
      json(res, 200, { token, user: publicUser(user) });
      return;
    }

    if (pathname === "/api/auth/me" && req.method === "GET") {
      const user = currentUser(req);
      if (!user) {
        json(res, 401, {
          error: "Your session has expired. Please sign in again.",
        });
        return;
      }
      json(res, 200, { user: publicUser(user) });
      return;
    }

    if (pathname === "/api/auth/logout" && req.method === "POST") {
      const token = req.headers.authorization?.replace(/^Bearer\s+/i, "");
      if (token) sessions.delete(token);
      json(res, 200, { ok: true });
      return;
    }

    if (pathname === "/api/billing/checkout" && req.method === "POST") {
      const user = requireRole(req, res, ["owner", "agent"]);
      if (!user) return;
      const body = await readBody(req);
      const plan = plans[body.planId];
      if (!plan || plan.id === "free") {
        json(res, 400, { error: "Choose a paid monthly plan." });
        return;
      }
      if (activePlanFor(user.id).id !== "free") {
        json(res, 409, {
          error:
            "You already have an active paid plan. Contact support to change plans.",
        });
        return;
      }
      const providerPlanId =
        process.env[`FLW_PLAN_${plan.id.toUpperCase()}_ID`];
      if (!providerPlanId) {
        json(res, 503, {
          error: `${plan.name} billing is not configured. Set its Flutterwave payment plan ID in the server environment.`,
        });
        return;
      }
      const txRef = `ewawe-${plan.id}-${randomUUID()}`;
      const checkout = await flutterwaveRequest("/payments", {
        method: "POST",
        body: JSON.stringify({
          tx_ref: txRef,
          amount: plan.monthlyPrice,
          currency: plan.currency,
          payment_plan: providerPlanId,
          redirect_url: `${PUBLIC_APP_URL}/?billing_return=1`,
          customer: {
            email: user.email,
            name: `${user.firstName} ${user.lastName}`,
            phonenumber: user.phone,
          },
          customizations: {
            title: `E-wawe ${plan.name}`,
            description: `${plan.name} monthly provider subscription`,
          },
          meta: { userId: user.id, planId: plan.id },
        }),
      });
      if (!checkout.link) {
        json(res, 502, {
          error: "Flutterwave did not return a checkout link.",
        });
        return;
      }
      const pendingPayments = load("pendingPayments.json");
      pendingPayments.unshift({
        txRef,
        userId: user.id,
        planId: plan.id,
        providerPlanId: String(providerPlanId),
        amount: plan.monthlyPrice,
        currency: plan.currency,
        createdAt: new Date().toISOString(),
      });
      save("pendingPayments.json", pendingPayments);
      json(res, 200, { checkoutUrl: checkout.link });
      return;
    }

    if (pathname === "/api/billing/verify" && req.method === "GET") {
      const user = requireRole(req, res, ["owner", "agent"]);
      if (!user) return;
      const transactionId = url.searchParams.get("transaction_id");
      const txRef = url.searchParams.get("tx_ref");
      if (!transactionId || !txRef || !/^\d+$/.test(transactionId)) {
        json(res, 400, {
          error: "The billing return is missing transaction details.",
        });
        return;
      }
      const result = await verifyCheckout(user, transactionId, txRef);
      json(res, 200, result);
      return;
    }

    if (pathname === "/api/billing/webhook" && req.method === "POST") {
      const webhookSecret = process.env.FLW_SECRET_HASH;
      if (!webhookSecret) {
        json(res, 503, { error: "Flutterwave webhooks are not configured." });
        return;
      }
      if (!secureStringEqual(req.headers["verif-hash"], webhookSecret)) {
        json(res, 401, { error: "Invalid Flutterwave webhook signature." });
        return;
      }
      const payload = await readBody(req);
      if (payload.event === "charge.completed" && payload.data?.id) {
        const email = String(payload.data.customer?.email || "").toLowerCase();
        const user = load("users.json").find((entry) => entry.email === email);
        const txRef = String(payload.data.tx_ref || "");
        const pending = load("pendingPayments.json").find(
          (payment) => payment.userId === user?.id && payment.txRef === txRef,
        );
        if (user && pending && payload.data.status === "successful") {
          await verifyCheckout(user, String(payload.data.id), txRef);
        } else if (user && payload.data.status === "successful") {
          const transactionId = String(payload.data.id);
          const events = load("billingEvents.json");
          if (!events.some((event) => event.transactionId === transactionId)) {
            const current = subscriptionFor(user.id);
            const plan = plans[current.planId];
            if (plan && plan.id !== "free" && current.status === "active") {
              const transaction = await flutterwaveRequest(
                `/transactions/${encodeURIComponent(transactionId)}/verify`,
              );
              const expectedPlanId =
                process.env[`FLW_PLAN_${plan.id.toUpperCase()}_ID`];
              if (
                transaction.status === "successful" &&
                Number(transaction.amount) === plan.monthlyPrice &&
                String(transaction.currency).toUpperCase() === plan.currency &&
                String(transaction.payment_plan || "") ===
                  String(expectedPlanId) &&
                String(transaction.customer?.email || "").toLowerCase() ===
                  user.email
              ) {
                const currentRenewal = Date.parse(current.renewsAt || "");
                const nextRenewal = new Date(
                  Math.max(
                    Date.now(),
                    Number.isFinite(currentRenewal) ? currentRenewal : 0,
                  ),
                );
                nextRenewal.setMonth(nextRenewal.getMonth() + 1);
                const subscriptions = load("subscriptions.json");
                const index = subscriptions.findIndex(
                  (item) => item.userId === user.id,
                );
                if (index >= 0) {
                  subscriptions[index] = {
                    ...current,
                    renewsAt: nextRenewal.toISOString(),
                    lastTransactionId: transactionId,
                  };
                  save("subscriptions.json", subscriptions);
                  events.push({
                    transactionId,
                    userId: user.id,
                    receivedAt: new Date().toISOString(),
                  });
                  save("billingEvents.json", events);
                }
              }
            }
          }
        }
      }
      if (payload.event === "subscription.cancelled") {
        const email = String(payload.data?.customer?.email || "").toLowerCase();
        const user = load("users.json").find((entry) => entry.email === email);
        const providerPlanId = String(payload.data?.plan?.id || "");
        const subscriptions = load("subscriptions.json");
        const index = subscriptions.findIndex(
          (subscription) =>
            subscription.userId === user?.id &&
            subscription.providerPlanId === providerPlanId,
        );
        if (index >= 0) {
          subscriptions[index].status = "cancelled";
          subscriptions[index].cancelledAt = new Date().toISOString();
          save("subscriptions.json", subscriptions);
        }
      }
      json(res, 200, { received: true });
      return;
    }

    if (pathname === "/api/billing/subscription" && req.method === "GET") {
      const user = requireRole(req, res, ["owner", "agent"]);
      if (!user) return;
      const subscription = subscriptionFor(user.id);
      json(res, 200, {
        subscription,
        plan: activePlanFor(user.id),
        plans: Object.values(plans),
      });
      return;
    }

    if (pathname === "/api/properties" && req.method === "GET") {
      const q = (url.searchParams.get("q") || "").trim().toLowerCase();
      const neighborhood = (url.searchParams.get("neighborhood") || "")
        .trim()
        .toLowerCase();
      const type = url.searchParams.get("type") || "";
      const minRent = Number(url.searchParams.get("minRent") || 0);
      const maxRent = Number(
        url.searchParams.get("maxRent") || Number.MAX_SAFE_INTEGER,
      );
      const minBedrooms = Number(url.searchParams.get("bedrooms") || 0);
      const properties = load("properties.json")
        .filter((property) => {
          const search =
            `${property.title} ${property.description} ${property.neighborhood} ${property.city}`.toLowerCase();
          return (
            (!q || search.includes(q)) &&
            (!neighborhood ||
              property.neighborhood.toLowerCase() === neighborhood) &&
            (!type || property.propertyType === type) &&
            property.rent >= minRent &&
            property.rent <= maxRent &&
            property.bedrooms >= minBedrooms
          );
        })
        .sort(
          (left, right) =>
            Number(Boolean(right.promoted)) - Number(Boolean(left.promoted)),
        );
      json(res, 200, {
        properties: properties.map((property) => safeProperty(property)),
      });
      return;
    }

    const contactMatch = pathname.match(
      /^\/api\/properties\/([^/]+)\/contact$/,
    );
    if (contactMatch && req.method === "POST") {
      const properties = load("properties.json");
      const index = properties.findIndex(
        (property) => property.id === contactMatch[1],
      );
      if (index < 0) {
        json(res, 404, { error: "Property not found." });
        return;
      }
      const property = properties[index];
      property.contactClicks = Number(property.contactClicks || 0) + 1;
      save("properties.json", properties);
      const inquiries = load("inquiries.json");
      const viewer = currentUser(req);
      inquiries.unshift({
        id: randomUUID(),
        propertyId: property.id,
        propertyTitle: property.title,
        renterId: viewer?.id || null,
        createdAt: new Date().toISOString(),
      });
      save("inquiries.json", inquiries);
      json(res, 200, { contact: property.contact });
      return;
    }

    const propertyMatch = pathname.match(/^\/api\/properties\/([^/]+)$/);
    if (propertyMatch && req.method === "GET") {
      const properties = load("properties.json");
      const index = properties.findIndex(
        (property) => property.id === propertyMatch[1],
      );
      if (index < 0) {
        json(res, 404, { error: "Property not found." });
        return;
      }
      properties[index].views = Number(properties[index].views || 0) + 1;
      save("properties.json", properties);
      json(res, 200, { property: safeProperty(properties[index]) });
      return;
    }

    if (pathname === "/api/my/properties" && req.method === "GET") {
      const user = requireRole(req, res, ["owner", "agent"]);
      if (!user) return;
      json(res, 200, {
        properties: load("properties.json").filter(
          (property) => property.ownerId === user.id,
        ),
      });
      return;
    }

    if (pathname === "/api/dashboard" && req.method === "GET") {
      const user = requireRole(req, res, ["owner", "agent"]);
      if (!user) return;
      const properties = load("properties.json").filter(
        (property) => property.ownerId === user.id,
      );
      const plan = activePlanFor(user.id);
      const ids = new Set(properties.map((property) => property.id));
      const inquiries = load("inquiries.json").filter((inquiry) =>
        ids.has(inquiry.propertyId),
      );
      const visibleProperties = properties.map((property) =>
        plan.analytics
          ? property
          : { ...property, views: undefined, contactClicks: undefined },
      );
      json(res, 200, {
        plan,
        subscription: subscriptionFor(user.id),
        plans: Object.values(plans),
        stats: {
          activeListings: properties.filter(
            (property) => property.status !== "rented",
          ).length,
          views: plan.analytics
            ? properties.reduce(
                (sum, property) => sum + Number(property.views || 0),
                0,
              )
            : null,
          inquiries: plan.inquiryManagement ? inquiries.length : null,
          contactClicks: plan.analytics
            ? properties.reduce(
                (sum, property) => sum + Number(property.contactClicks || 0),
                0,
              )
            : null,
        },
        properties: visibleProperties,
        inquiries: plan.inquiryManagement ? inquiries.slice(0, 10) : [],
      });
      return;
    }

    if (pathname === "/api/properties" && req.method === "POST") {
      const user = requireRole(req, res, ["owner", "agent"]);
      if (!user) return;
      const body = await readBody(req);
      const errors = validateProperty(body);
      if (errors.length) {
        json(res, 400, { error: errors[0], errors });
        return;
      }
      const properties = load("properties.json");
      const plan = activePlanFor(user.id);
      const activeListings = properties.filter(
        (property) =>
          property.ownerId === user.id && property.status !== "rented",
      );
      if (
        plan.maxListings !== null &&
        activeListings.length >= plan.maxListings
      ) {
        json(res, 403, {
          error: `Your ${plan.name} plan allows ${plan.maxListings} active listing${plan.maxListings === 1 ? "" : "s"}. Upgrade to publish another property.`,
          code: "LISTING_LIMIT_REACHED",
        });
        return;
      }
      const promotedCount = activeListings.filter(
        (property) => property.promoted,
      ).length;
      const property = {
        id: randomUUID(),
        title: body.title.trim(),
        description: body.description.trim(),
        neighborhood: body.neighborhood,
        city: "Kigali",
        rent: Number(body.rent),
        bedrooms: Number(body.bedrooms),
        bathrooms: Number(body.bathrooms),
        areaSqm: Number(body.areaSqm),
        propertyType: body.propertyType,
        availableDate: body.availableDate,
        leaseTerm: body.leaseTerm.trim(),
        amenities: body.amenities,
        images: body.images || [],
        ownerId: user.id,
        contact: {
          name: `${user.firstName} ${user.lastName}`,
          role: user.role,
          phone: user.phone,
          email: user.email,
          whatsapp: user.phone.replace(/\s+/g, ""),
        },
        views: 0,
        contactClicks: 0,
        createdAt: new Date().toISOString(),
        status: "active",
        promoted: promotedCount < plan.promotedSlots,
      };
      properties.unshift(property);
      save("properties.json", properties);
      json(res, 201, { property });
      return;
    }

    json(res, 404, { error: "That API route was not found." });
  } catch (error) {
    console.error(error);
    json(res, error.status || 500, {
      error: error.status
        ? error.message
        : "The server could not complete that request.",
    });
  }
});

// Validate and bound property listing fields before they are written to JSON.
function validateProperty(body) {
  const errors = [];
  if (
    typeof body.title !== "string" ||
    body.title.trim().length < 5 ||
    body.title.trim().length > 100
  )
    errors.push("Add a property title between 5 and 100 characters.");
  if (
    typeof body.description !== "string" ||
    body.description.trim().length < 30 ||
    body.description.trim().length > 5000
  )
    errors.push("Write a description between 30 and 5,000 characters.");
  if (
    ![
      "Kiyovu",
      "Kimihurura",
      "Nyarutarama",
      "Kacyiru",
      "Remera",
      "Kibagabaga",
      "Gacuriro",
      "Other",
    ].includes(body.neighborhood)
  )
    errors.push("Choose a Kigali neighborhood.");
  if (
    !Number.isFinite(Number(body.rent)) ||
    Number(body.rent) < 1 ||
    Number(body.rent) > 10000000
  )
    errors.push("Enter a valid monthly rent.");
  if (
    !Number.isInteger(Number(body.bedrooms)) ||
    Number(body.bedrooms) < 0 ||
    Number(body.bedrooms) > 30
  )
    errors.push("Enter a valid bedroom count.");
  if (
    !Number.isFinite(Number(body.bathrooms)) ||
    Number(body.bathrooms) < 0 ||
    Number(body.bathrooms) > 30
  )
    errors.push("Enter a valid bathroom count.");
  if (
    !Number.isFinite(Number(body.areaSqm)) ||
    Number(body.areaSqm) < 10 ||
    Number(body.areaSqm) > 10000
  )
    errors.push("Enter the floor area in square metres.");
  if (
    !["Apartment", "House", "Townhouse", "Villa", "Other"].includes(
      body.propertyType,
    )
  )
    errors.push("Choose a property type.");
  if (
    typeof body.availableDate !== "string" ||
    !/^\d{4}-\d{2}-\d{2}$/.test(body.availableDate)
  )
    errors.push("Choose an availability date.");
  if (
    typeof body.leaseTerm !== "string" ||
    body.leaseTerm.trim().length < 2 ||
    body.leaseTerm.length > 50
  )
    errors.push("Enter a valid lease term.");
  if (
    !Array.isArray(body.images) ||
    body.images.length < 1 ||
    body.images.length > 5 ||
    body.images.some(
      (image) =>
        typeof image !== "string" ||
        (!/^https:\/\//.test(image) &&
          !/^data:image\/(jpeg|png|webp);base64,/.test(image)) ||
        image.length > 4_000_000,
    )
  )
    errors.push(
      "Add 1–5 JPG, PNG, or WebP property photos, each no larger than 2 MB.",
    );
  if (
    !Array.isArray(body.amenities) ||
    body.amenities.length > 30 ||
    body.amenities.some((item) => typeof item !== "string" || item.length > 60)
  )
    errors.push("Check the amenities and try again.");
  return errors;
}

// Start the local API on loopback for Vite's development proxy.
server.on("error", (error) => {
  if (error.code === "EADDRINUSE") {
    console.error(
      `Port ${PORT} is already in use. Stop the process using it or set a free API_PORT in .env.`,
    );
    process.exitCode = 1;
    return;
  }
  console.error("The E-wawe API could not start:", error.message);
  process.exitCode = 1;
});
server.listen(PORT, "127.0.0.1", () =>
  console.log(`E-wawe API ready at http://localhost:${PORT}`),
);
